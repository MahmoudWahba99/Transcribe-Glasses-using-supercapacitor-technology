import asyncio
import websockets
import argparse
import numpy as np
import speech_recognition as sr
from datetime import datetime, timedelta
from queue import Queue
from sys import platform

async def send_audio(websocket):
    parser = argparse.ArgumentParser()
    parser.add_argument("--energy_threshold", default=1000,
                        help="Energy level for mic to detect.", type=int)
    parser.add_argument("--record_timeout", default=2,
                        help="How real time the recording is in seconds.", type=float)
    parser.add_argument("--phrase_timeout", default=3,
                        help="How much empty space between recordings before we "
                             "consider it a new line in the transcription.", type=float)
    if 'linux' in platform:
        parser.add_argument("--default_microphone", default='pulse',
                            help="Default microphone name for SpeechRecognition. "
                                 "Run this with 'list' to view available Microphones.", type=str)
    args = parser.parse_args()

    # The last time a recording was retrieved from the queue.
    phrase_time = None
    # Thread safe Queue for passing data from the threaded recording callback.
    data_queue = Queue()
    # We use SpeechRecognizer to record our audio because it has a nice feature where it can detect when speech ends.
    recorder = sr.Recognizer()
    recorder.energy_threshold = args.energy_threshold
    # Definitely do this, dynamic energy compensation lowers the energy threshold dramatically to a point where the SpeechRecognizer never stops recording.
    recorder.dynamic_energy_threshold = False

    # Important for linux users.
    # Prevents permanent application hang and crash by using the wrong Microphone
    if 'linux' in platform:
        mic_name = args.default_microphone
        if not mic_name or mic_name == 'list':
            print("Available microphone devices are: ")
            for index, name in enumerate(sr.Microphone.list_microphone_names()):
                print(f"Microphone with name \"{name}\" found")
            return
        else:
            for index, name in enumerate(sr.Microphone.list_microphone_names()):
                if mic_name in name:
                    source = sr.Microphone(sample_rate=16000, device_index=index)
                    break
    else:
        source = sr.Microphone(sample_rate=16000)

    record_timeout = args.record_timeout
    phrase_timeout = args.phrase_timeout

    with source:
        recorder.adjust_for_ambient_noise(source)

    def record_callback(_, audio:sr.AudioData) -> None:
        """
        Threaded callback function to receive audio data when recordings finish.
        audio: An AudioData containing the recorded bytes.
        """
        # Grab the raw bytes and push it into the thread safe queue.
        data = audio.get_raw_data()
        data_queue.put(data)

    # Create a background thread that will pass us raw audio bytes.
    # We could do this manually but SpeechRecognizer provides a nice helper.
    recorder.listen_in_background(source, record_callback, phrase_time_limit=record_timeout)

    # Cue the user that we're ready to go.
    print("(Mic Script & Reciveing Data from Server (I am The ESP32)\n")

    while True:
        try:
            await asyncio.sleep(0.25)
            if not data_queue.empty():
                # Combine audio data from queue
                audio_data = b''.join(data_queue.queue)
                data_queue.queue.clear()

                # Send audio data to the WebSocket server
                await websocket.send(audio_data)

                # Receive the transcribed text from the server
                response = await websocket.recv()
                print(f"Received text: {response}")
        except KeyboardInterrupt:
            break


async def hello():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri) as websocket:
        await send_audio(websocket)


if __name__ == "__main__":
    asyncio.run(hello())

# import asyncio
# import websockets
# import argparse
# import numpy as np
# import speech_recognition as sr
# from datetime import datetime, timedelta
# from queue import Queue
# from sys import platform

# async def send_audio(websocket):
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--energy_threshold", default=1000,
#                         help="Energy level for mic to detect.", type=int)
#     parser.add_argument("--record_timeout", default=2,
#                         help="How real time the recording is in seconds.", type=float)
#     parser.add_argument("--phrase_timeout", default=3,
#                         help="How much empty space between recordings before we "
#                              "consider it a new line in the transcription.", type=float)
#     if 'linux' in platform:
#         parser.add_argument("--default_microphone", default='pulse',
#                             help="Default microphone name for SpeechRecognition. "
#                                  "Run this with 'list' to view available Microphones.", type=str)
#     args = parser.parse_args()

#     # The last time a recording was retrieved from the queue.
#     phrase_time = None
#     # Thread safe Queue for passing data from the threaded recording callback.
#     data_queue = Queue()
#     # We use SpeechRecognizer to record our audio because it has a nice feature where it can detect when speech ends.
#     recorder = sr.Recognizer()
#     recorder.energy_threshold = args.energy_threshold
#     # Definitely do this, dynamic energy compensation lowers the energy threshold dramatically to a point where the SpeechRecognizer never stops recording.
#     recorder.dynamic_energy_threshold = False

#     # Important for linux users.
#     # Prevents permanent application hang and crash by using the wrong Microphone
#     if 'linux' in platform:
#         mic_name = args.default_microphone
#         if not mic_name or mic_name == 'list':
#             print("Available microphone devices are: ")
#             for index, name in enumerate(sr.Microphone.list_microphone_names()):
#                 print(f"Microphone with name \"{name}\" found")
#             return
#         else:
#             for index, name in enumerate(sr.Microphone.list_microphone_names()):
#                 if mic_name in name:
#                     source = sr.Microphone(sample_rate=16000, device_index=index)
#                     break
#     else:
#         source = sr.Microphone(sample_rate=16000)

#     record_timeout = args.record_timeout
#     phrase_timeout = args.phrase_timeout

#     with source:
#         recorder.adjust_for_ambient_noise(source)

#     def record_callback(_, audio:sr.AudioData) -> None:
#         """
#         Threaded callback function to receive audio data when recordings finish.
#         audio: An AudioData containing the recorded bytes.
#         """
#         # Grab the raw bytes and push it into the thread safe queue.
#         data = audio.get_raw_data()
#         data_queue.put(data)

#     # Create a background thread that will pass us raw audio bytes.
#     # We could do this manually but SpeechRecognizer provides a nice helper.
#     recorder.listen_in_background(source, record_callback, phrase_time_limit=record_timeout)

#     # Cue the user that we're ready to go.
#     print("Microphone capture started.\n")

#     while True:
#         try:
#             await asyncio.sleep(0.25)
#             if not data_queue.empty():
#                 # Combine audio data from queue
#                 audio_data = b''.join(data_queue.queue)
#                 data_queue.queue.clear()

#                 # Send audio data to the WebSocket server
#                 await websocket.send(audio_data)
#         except KeyboardInterrupt:
#             break


# async def hello():
#     uri = "ws://localhost:8765"
#     async with websockets.connect(uri) as websocket:
#         await send_audio(websocket)


# if __name__ == "__main__":
#     asyncio.run(hello())

# import asyncio
# import websockets

# async def hello():
#     uri = "ws://localhost:8765"
#     async with websockets.connect(uri) as websocket:
#         message = "Hello, WebSocket!"
#         await websocket.send(message)
#         print(f"Sent: {message}")

#         response = await websocket.recv()
#         print(f"Received: {response}")

# if __name__ == "__main__":
#     asyncio.run(hello())
