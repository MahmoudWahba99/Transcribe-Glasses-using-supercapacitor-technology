
import asyncio
import websockets
import numpy as np
import torch
import whisper

# Load / Download model
model_name = "tiny"
audio_model = whisper.load_model(model_name)

async def handler(websocket, path):
    print(f"Client connected: {path} )")

    try:
        async for message in websocket:
            # Assuming message is the raw audio data in bytes
            audio_np = np.frombuffer(message, dtype=np.int16).astype(np.float32) / 32768.0

            # Process the audio using the server-side model
            result = audio_model.transcribe(audio_np, fp16=torch.cuda.is_available())
            text = result['text'].strip()

            # Respond with the transcribed text
            # print(f"Transcribed text: {text}")
            await websocket.send(text)

    except websockets.ConnectionClosed as e:
        print(f"Client disconnected: {e.reason}")


async def main():
    server = await websockets.serve(handler, "localhost", 8765)
    print("WebSocket server started on ws://localhost:8765")
    await server.wait_closed()


if __name__ == "__main__":
    asyncio.run(main())


# import asyncio
# import websockets
# import numpy as np
# import torch
# import whisper

# # Load / Download model
# model_name = "tiny"
# audio_model = whisper.load_model(model_name)

# async def handler(websocket, path):
#     print(f"Client connected: {path}")

#     try:
#         async for message in websocket:
#             # Assuming message is the raw audio data in bytes
#             audio_np = np.frombuffer(message, dtype=np.int16).astype(np.float32) / 32768.0

#             # Process the audio using the server-side model
#             result = audio_model.transcribe(audio_np, fp16=torch.cuda.is_available())
#             text = result['text'].strip()

#             # Respond with the transcribed text
#             response = text
#             await websocket.send(response)
#             print(f"Sent response: {response}")

#     except websockets.ConnectionClosed as e:
#         print(f"Client disconnected: {e.reason}")


# async def main():
#     server = await websockets.serve(handler, "localhost", 8765)
#     print("WebSocket server started on ws://localhost:8765")
#     await server.wait_closed()


# if __name__ == "__main__":
#     asyncio.run(main())

# import asyncio
# import websockets

# async def handler(websocket, path):
#     print(f"Client connected: {path}")
#     try:
#         async for message in websocket:
#             print(f"Received message: {message}")
#             response = f"Echo: {message}"
#             await websocket.send(response)
#             print(f"Sent response: {response}")
#     except websockets.ConnectionClosed as e:
#         print(f"Client disconnected: {e.reason}")

# async def main():
#     server = await websockets.serve(handler, "localhost", 8765)
#     print("WebSocket server started on ws://localhost:8765")
#     await server.wait_closed()

# if __name__ == "__main__":
#     asyncio.run(main())
